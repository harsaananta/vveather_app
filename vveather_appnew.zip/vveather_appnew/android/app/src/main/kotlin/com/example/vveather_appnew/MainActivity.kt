package com.example.vveather_appnew

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
