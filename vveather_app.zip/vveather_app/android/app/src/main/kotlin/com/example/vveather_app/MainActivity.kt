package com.example.vveather_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
